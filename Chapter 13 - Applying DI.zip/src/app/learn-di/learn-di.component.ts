import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learn-di',
  templateUrl: './learn-di.component.html',
  styleUrls: ['./learn-di.component.css']
})
export class LearnDiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
