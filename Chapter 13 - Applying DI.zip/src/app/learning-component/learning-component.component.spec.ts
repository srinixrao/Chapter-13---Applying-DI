import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LearningComponentComponent } from './learning-component.component';

/*
describe('LearningComponentComponent', () => {

  it('Test learning component', () => {
  let component = new LearningComponentComponent();
    expect(component).toBeTruthy();
  });
});
*/